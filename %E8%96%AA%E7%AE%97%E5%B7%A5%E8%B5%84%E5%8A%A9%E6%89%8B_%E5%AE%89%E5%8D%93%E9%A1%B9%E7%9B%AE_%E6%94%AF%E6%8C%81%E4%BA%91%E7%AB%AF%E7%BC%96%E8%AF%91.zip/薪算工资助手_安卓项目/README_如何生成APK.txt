薪算工资助手 Android 项目（支持云端自动编译）
================================================

最简单的办法：使用 GitHub 云端自动编译 APK，不用在自己的电脑安装 Android Studio。

一、创建 GitHub 仓库
1. 浏览器打开 https://github.com/ 并登录/注册。
2. 点击右上角 +，选择 New repository。
3. 仓库名称填 mingtian-salary-app，选择 Public 或 Private 均可，然后点 Create repository。

二、上传本项目文件
1. 解压“薪算工资助手_安卓项目.zip”。
2. 进入刚解压的“薪算工资助手_安卓项目”文件夹。
3. 在 GitHub 新建仓库页面，点击 uploading an existing file（或 Add file > Upload files）。
4. 把该文件夹里面的所有文件和文件夹上传到仓库根目录。注意要包含 app、.github、build.gradle、settings.gradle 等文件；不要只上传外层 ZIP。
5. 在页面底部点击 Commit changes。

三、下载 APK
1. 打开仓库里的 Actions 页面。
2. 选择 “Build Salary App APK” 工作流；如果 push 后自动开始了，直接点最新一次运行。
3. 等待运行完成（绿色勾）。
4. 打开该次运行详情，在页面下方 Artifacts 区域下载 salary-app-debug-apk。
5. 解压下载的 ZIP，里面的 app-debug.apk 就是安卓安装包。

安装说明：
- 把 app-debug.apk 下载到安卓手机并点击安装。
- 如果手机提示禁止安装，进入系统设置，允许当前浏览器/文件管理器“安装未知应用”，再重试。
- 这是用于个人测试的 debug APK；不是经过商店审核的正式发布包。

应用说明：
- 应用名：薪算工资助手
- 最低 Android 版本：Android 6.0（API 23）
- 工资记录在本机保存，不需要登录。
- 请定期使用应用内“导出备份 JSON”功能备份数据。
- 工资计算仅供个人估算，实际工资以工资条及税务结果为准。

隐私提醒：
仓库若选择 Public，上传的源码会公开。项目当前不包含你的个人工资数据；请勿上传含真实工资记录的 JSON 备份。
